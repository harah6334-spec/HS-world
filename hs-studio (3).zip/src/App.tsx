/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter, useLocation } from 'react-router-dom';
import { useEffect, Suspense } from 'react';
import { HelmetProvider } from 'react-helmet-async';
import { ThemeProvider } from './components/ThemeProvider';
import { AuthProvider } from './context/AuthContext';
import Navbar from './components/layout/Navbar';
import Footer from './components/layout/Footer';
import AnimatedRoutes from './pages/AnimatedRoutes';
import { Canvas } from '@react-three/fiber';
import { ParallaxStars, GlowingSphere, FloatingGeometry } from './components/3d/BackgroundScene';
import PostEffects from './components/3d/PostEffects';

function ScrollToTop() {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  return null;
}

function GlobalCanvas() {
  const { pathname } = useLocation();
  
  let color1 = "#6366f1"; // Neon Blue/Indigo
  let color2 = "#a855f7"; // Neon Purple

  if (pathname === '/about') {
    color1 = "#ec4899"; // Pink
    color2 = "#8b5cf6"; // Violet
  } else if (pathname === '/services') {
    color1 = "#10b981"; // Emerald
    color2 = "#3b82f6"; // Blue
  } else if (pathname === '/portfolio') {
    color1 = "#f43f5e"; // Rose
    color2 = "#f59e0b"; // Amber
  } else if (pathname === '/contact') {
    color1 = "#0ea5e9"; // Sky
    color2 = "#6366f1"; // Indigo
  } else if (pathname === '/payment') {
    color1 = "#4ade80"; // Green
    color2 = "#3b82f6"; // Blue
  } else if (pathname === '/login') {
    color1 = "#8b5cf6"; // Violet
    color2 = "#ec4899"; // Pink
  }

  return (
    <div className="fixed inset-0 z-0 pointer-events-none transition-colors duration-1000">
      <Canvas camera={{ position: [0, 0, 5], fov: 75 }} gl={{ antialias: false, alpha: true }}>
        <Suspense fallback={null}>
          <ParallaxStars />
          <FloatingGeometry position={[4, 2, -5]} />
          <FloatingGeometry position={[-6, -3, -8]} />
          <GlowingSphere color={color1} position={[-5, 2, -10]} />
          <GlowingSphere color={color2} position={[5, -2, -8]} />
          <PostEffects />
        </Suspense>
      </Canvas>
    </div>
  );
}

export default function App() {
  return (
    <HelmetProvider>
      <ThemeProvider defaultTheme="dark" storageKey="hs-theme">
        <AuthProvider>
          <BrowserRouter>
            <ScrollToTop />
            <div className="flex flex-col min-h-screen bg-[var(--color-v3-surface)] text-[var(--color-v3-text)]">
              <GlobalCanvas />
              <Navbar />
              <main className="flex-grow pt-24 relative z-10">
                <AnimatedRoutes />
              </main>
              <Footer />
            </div>
          </BrowserRouter>
        </AuthProvider>
      </ThemeProvider>
    </HelmetProvider>
  );
}
