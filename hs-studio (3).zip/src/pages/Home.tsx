import { motion } from 'motion/react';
import { ArrowRight, Code, Layout, ChevronRight, Download, Server } from 'lucide-react';
import { Link } from 'react-router-dom';
import SEO from '../components/SEO';
import HeroScene from '../components/3d/HeroScene';
import { useState, useEffect } from 'react';

const roles = ["Web Developer", "UI/UX Designer", "Full Stack Developer", "Creative Technologist"];

function TypingRoles() {
  const [currentRoleIndex, setCurrentRoleIndex] = useState(0);
  const [currentText, setCurrentText] = useState('');
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    const role = roles[currentRoleIndex];
    let timeout: NodeJS.Timeout;

    if (!isDeleting && currentText === role) {
      timeout = setTimeout(() => setIsDeleting(true), 2000);
    } else if (isDeleting && currentText === '') {
      setIsDeleting(false);
      setCurrentRoleIndex((prev) => (prev + 1) % roles.length);
    } else {
      const nextText = isDeleting 
        ? role.substring(0, currentText.length - 1)
        : role.substring(0, currentText.length + 1);
      
      timeout = setTimeout(() => setCurrentText(nextText), isDeleting ? 50 : 100);
    }

    return () => clearTimeout(timeout);
  }, [currentText, isDeleting, currentRoleIndex]);

  return (
    <span className="text-gradient font-semibold">
      {currentText}
      <span className="animate-pulse">|</span>
    </span>
  );
}

export default function Home() {
  const handleDownloadCV = () => {
    const content = "CV\n\nExperience: 2 Years\nProjects: 20+\nLocation: Balrampur, India";
    const blob = new Blob([content], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "Resume_Acme_Studio.txt";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <>
    <SEO title="Home" description="HS Studio - Expert Web Development and Design." />
    <div className="flex flex-col gap-32 pb-24 relative">
      {/* Hero Section */}
      <section className="relative px-6 min-h-[80vh] flex items-center justify-center pt-24 overflow-hidden">
        <HeroScene />
        <div className="max-w-7xl mx-auto w-full relative z-10 flex flex-col items-center text-center">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="max-w-4xl flex flex-col items-center"
          >
            <div className="small-caps mb-6 text-[var(--color-v3-accent)] tracking-widest bg-[var(--color-v3-accent)]/10 px-4 py-1.5 rounded-full border border-[var(--color-v3-accent)]/20 shadow-[0_0_15px_rgba(99,102,241,0.2)]">Digital Design & Development</div>
            <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold tracking-tighter leading-[1.1] mb-8 text-[var(--color-v3-text)]">
              Crafting <br className="hidden md:block"/> <span className="text-gradient">Future-Proof</span> <br className="hidden md:block" /> Digital Experiences
            </h1>
            <p className="text-xl md:text-2xl text-[var(--color-v3-text-var)] font-light mb-12 max-w-2xl mx-auto h-[40px]">
              Hi, I'm a <TypingRoles />
            </p>
            <div className="flex flex-col sm:flex-row gap-6 justify-center w-full sm:w-auto">
              <Link to="/contact" className="nav-pill primary text-lg px-8 py-4 gap-2 group w-full sm:w-auto">
                Start a project <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Link>
              <Link to="/portfolio" className="nav-pill text-lg px-8 py-4 gap-2 w-full sm:w-auto">
                View our work
              </Link>
            </div>
            <button onClick={handleDownloadCV} className="mt-8 text-sm text-[var(--color-v3-text-var)] hover:text-[var(--color-v3-accent)] flex items-center justify-center gap-2 transition-colors">
              <Download className="w-4 h-4" /> Download CV
            </button>
          </motion.div>
        </div>
      </section>

      {/* Intro Image / Video Placeholder */}
      <section className="px-6">
        <div className="max-w-7xl mx-auto">
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 1 }}
            className="relative aspect-video rounded-3xl overflow-hidden glass-border p-2"
          >
            <div className="w-full h-full rounded-2xl overflow-hidden relative">
              <img 
                src="https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&q=80&w=2569" 
                alt="Office space"
                className="w-full h-full object-cover opacity-60 hover:opacity-100 transition-opacity duration-700 hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-[#0a0a0a]/50 to-transparent flex items-end p-8 md:p-12 pointer-events-none">
                 <div>
                   <div className="text-[var(--color-v3-text)] text-2xl font-light italic mb-2">"Beautifully structured, inside and out."</div>
                   <div className="small-caps">Our Philosophy</div>
                 </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Services Section */}
      <section className="px-6 relative mb-24">
         <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-16">
            <div>
              <h2 className="text-4xl md:text-6xl font-bold tracking-tight text-[var(--color-v3-text)] mb-6"><span className="text-[var(--color-v3-text-var)] text-3xl md:text-4xl">01 //</span> Expertise.</h2>
              <p className="text-[var(--color-v3-text-var)] text-lg font-light mb-8 max-w-md">
                We combine strategic thinking with high-end design and robust engineering to deliver complete solutions.
              </p>
              <Link to="/services" className="inline-flex items-center gap-2 text-[var(--color-v3-accent)] hover:text-[var(--color-v3-accent-4)] transition-colors border-b border-transparent hover:border-[var(--color-v3-accent-4)] pb-1 font-medium">
                 View all services <ChevronRight className="w-4 h-4" />
              </Link>
            </div>
            
            <div className="flex flex-col gap-12">
               {[
                 { icon: Layout, title: "UI/UX Design", desc: "Creating intuitive, engaging, and beautiful user interfaces that convert." },
                 { icon: Code, title: "Web Development", desc: "Building fast, scaleable, and resilient web applications using modern tech stacks." },
                 { icon: Server, title: "Full Stack Development", desc: "End-to-end setups handling databases, robust APIs, and interactive frontends." }
               ].map((service, i) => (
                 <motion.div 
                    key={i}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.1, duration: 0.5 }}
                    className="flex gap-6 group cursor-pointer"
                 >
                    <div className="shrink-0 w-16 h-16 rounded-2xl glass-border flex items-center justify-center text-[var(--color-v3-accent)] group-hover:scale-110 group-hover:shadow-[0_0_20px_rgba(99,102,241,0.3)] transition-all duration-300 relative overflow-hidden">
                      <div className="absolute inset-0 bg-gradient-to-br from-[var(--color-v3-accent)]/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                      <service.icon className="w-7 h-7 relative z-10 group-hover:text-[var(--color-v3-text)] transition-colors" />
                    </div>
                    <div>
                      <h3 className="text-2xl font-semibold text-[var(--color-v3-text)] mb-2 group-hover:text-gradient transition-colors">{service.title}</h3>
                      <p className="text-[var(--color-v3-text-var)] font-light leading-relaxed group-hover:text-white/80 transition-colors">{service.desc}</p>
                    </div>
                 </motion.div>
               ))}
            </div>
         </div>
      </section>
    </div>
    </>
  );
}
