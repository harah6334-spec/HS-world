import { motion } from 'motion/react';
import { CreditCard, Copy, CheckCheck, Phone, Info, Calendar, HandCoins, ExternalLink } from 'lucide-react';
import { useState, useEffect } from 'react';
import { collection, onSnapshot, query, orderBy, addDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { handleFirestoreError, OperationType } from '../lib/firestoreUtils';
import SEO from '../components/SEO';
import ContactScene from '../components/3d/ContactScene';

interface Transaction {
  id: string;
  date: string;
  amount: number;
  description: string;
  status: string;
}

export default function Payment() {
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [isSimulating, setIsSimulating] = useState(false);

  const phonepeNumber = "9098495546";
  const upiId = "9098495546-2@ybl";
  const upiDeepLink = "upi://pay?pa=9098495546-2@ybl&pn=HS%20Studio&cu=INR";
  const phonepeDeepLink = "phonepe://pay?pa=9098495546-2@ybl&pn=HS Studio&cu=INR";
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(upiDeepLink)}`;

  const handleCopy = (text: string, field: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(field);
    setTimeout(() => setCopiedField(null), 2000);
  };

  useEffect(() => {
    const q = query(collection(db, 'transactions'), orderBy('date', 'desc'));
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const txs: Transaction[] = [];
      snapshot.forEach((doc) => {
        txs.push({ id: doc.id, ...doc.data() } as Transaction);
      });
      setTransactions(txs);
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'transactions');
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const simulatePayment = async () => {
    setIsSimulating(true);
    try {
      const newTransaction = {
        date: new Date().toISOString(),
        description: 'Simulated Project Payment',
        amount: Math.floor(Math.random() * 5000) + 500,
        status: 'completed'
      };
      
      await addDoc(collection(db, 'transactions'), newTransaction);
      // Wait a moment before resetting the UI state to show completion visually
      setTimeout(() => setIsSimulating(false), 500);
    } catch (error) {
      setIsSimulating(false);
      handleFirestoreError(error, OperationType.CREATE, 'transactions');
    }
  };

  return (
    <>
    <SEO title="Payment" description="Make a payment to HS Studio seamlessly via UPI." />
    <div className="pt-12 pb-24 px-6 relative">
      <div className="absolute top-1/4 left-0 md:left-1/4 w-full md:w-3/4 h-[800px] z-0 opacity-40 ">
         <ContactScene />
      </div>
      <div className="max-w-7xl mx-auto flex flex-col lg:flex-row gap-16 lg:gap-24 relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full lg:w-1/2"
        >
          <div className="small-caps mb-6 text-[var(--color-v3-accent)] tracking-widest bg-[var(--color-v3-accent)]/10 px-4 py-1.5 rounded-full inline-block border border-[var(--color-v3-accent)]/20 shadow-[0_0_15px_rgba(99,102,241,0.2)]">Make a Payment</div>
          <h1 className="text-5xl md:text-7xl font-bold tracking-tighter mb-8 text-[var(--color-v3-text)]">
            Pay <br /><span className="text-gradient italic font-light">seamlessly.</span>
          </h1>
          <p className="text-xl text-[var(--color-v3-text-var)] font-light leading-relaxed mb-16">
            Pay directly via UPI or PhonePe. Scan the QR code, use the direct payment links, or copy the details to pay manually from your preferred app.
          </p>

          <div className="flex flex-col gap-10">
            <div className="flex items-center gap-6 text-[var(--color-v3-text)] group">
               <div className="w-16 h-16 rounded-2xl glass-border flex items-center justify-center text-[var(--color-v3-accent)] group-hover:scale-110 group-hover:shadow-[0_0_20px_rgba(99,102,241,0.3)] transition-all duration-300 relative overflow-hidden">
                 <div className="absolute inset-0 bg-gradient-to-br from-[var(--color-v3-accent)]/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                 <Phone className="w-6 h-6 relative z-10 group-hover:text-[var(--color-v3-text)] transition-colors" />
               </div>
               <div className="flex-grow">
                  <div className="text-sm font-medium text-[var(--color-v3-text-var)] mb-1 uppercase tracking-wider">PhonePe Number</div>
                  <div className="text-xl font-medium">{phonepeNumber}</div>
               </div>
               <button 
                 onClick={() => handleCopy(phonepeNumber, 'phone')}
                 className="p-3 rounded-xl hover:bg-[var(--color-v3-surface-container-high)] border border-transparent hover:border-[var(--color-v3-outline)] transition-all text-[var(--color-v3-text-var)] hover:text-white"
                 aria-label="Copy PhonePe Number"
               >
                 {copiedField === 'phone' ? <CheckCheck className="w-5 h-5 text-emerald-400" /> : <Copy className="w-5 h-5" />}
               </button>
            </div>

            <div className="flex items-center gap-6 text-[var(--color-v3-text)] group">
               <div className="w-16 h-16 rounded-2xl glass-border flex items-center justify-center text-[var(--color-v3-accent)] group-hover:scale-110 group-hover:shadow-[0_0_20px_rgba(99,102,241,0.3)] transition-all duration-300 relative overflow-hidden">
                 <div className="absolute inset-0 bg-gradient-to-br from-[var(--color-v3-accent)]/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                 <CreditCard className="w-6 h-6 relative z-10 group-hover:text-[var(--color-v3-text)] transition-colors" />
               </div>
               <div className="flex-grow">
                  <div className="text-sm font-medium text-[var(--color-v3-text-var)] mb-1 uppercase tracking-wider">UPI ID</div>
                  <div className="text-xl font-medium">{upiId}</div>
               </div>
               <button 
                 onClick={() => handleCopy(upiId, 'upi')}
                 className="p-3 rounded-xl hover:bg-[var(--color-v3-surface-container-high)] border border-transparent hover:border-[var(--color-v3-outline)] transition-all text-[var(--color-v3-text-var)] hover:text-white"
                 aria-label="Copy UPI ID"
               >
                 {copiedField === 'upi' ? <CheckCheck className="w-5 h-5 text-emerald-400" /> : <Copy className="w-5 h-5" />}
               </button>
            </div>
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
          className="w-full lg:w-1/2 flex justify-center lg:justify-end"
        >
          <div className="glass-border rounded-[2.5rem] p-8 md:p-12 relative overflow-hidden w-full max-w-md flex flex-col items-center">
            <div className="absolute top-0 right-0 w-64 h-64 bg-[var(--color-v3-accent)]/10 rounded-full blur-3xl -z-10 translate-x-1/3 -translate-y-1/3" />
            
            <div className="bg-white p-4 rounded-3xl mb-4 relative group">
              <div className="absolute inset-0 bg-gradient-to-tr from-[var(--color-v3-accent)] to-[var(--color-v3-accent-4)] blur-xl opacity-20 -z-10 group-hover:opacity-40 transition-opacity duration-300"></div>
              <img 
                src="https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=upi://pay?pa=9098495546-2@ybl%26pn=HS%20Studio%26cu=INR" 
                alt="UPI QR Code" 
                className="w-[220px] h-[220px] rounded-xl object-contain mx-auto"
              />
            </div>
            
            <p className="text-[var(--color-v3-text-var)] text-sm font-medium mb-8 uppercase tracking-wider text-center">Scan to Pay via any UPI App</p>

            <div className="w-full flex flex-col gap-4 relative z-10">
              <a 
                href={phonepeDeepLink}
                className="nav-pill primary block w-full text-center py-4 group/btn overflow-hidden relative"
              >
                <span className="relative z-10 flex items-center justify-center gap-2 text-lg">
                  Pay with PhonePe
                </span>
                <div className="absolute inset-0 bg-gradient-to-r from-[var(--color-v3-accent-4)] to-[var(--color-v3-accent)] opacity-0 group-hover/btn:opacity-100 transition-opacity duration-300" />
              </a>
              
              <a 
                href={upiDeepLink}
                className="nav-pill block w-full text-center py-4 bg-[var(--color-v3-surface-container-high)] text-white hover:bg-[var(--color-v3-surface-container-highest)] border border-[var(--color-v3-outline)] hover:border-white/20 transition-all font-medium"
              >
                Open in UPI App
              </a>
            </div>

            <p className="mt-4 text-xs font-medium text-[var(--color-v3-text-var)] text-center w-full uppercase tracking-widest">
              Supports PhonePe, Google Pay, Paytm, and all UPI apps
            </p>

            <div className="mt-8 flex items-start gap-3 p-4 rounded-2xl bg-[var(--color-v3-surface-container)] border border-[var(--color-v3-outline)] text-[var(--color-v3-text-var)]">
              <Info className="w-5 h-5 flex-shrink-0 text-blue-400 mt-0.5" />
              <p className="text-sm font-light leading-relaxed">
                If the buttons don't open your UPI app automatically, please scan the QR code using another device or copy the UPI ID above.
              </p>
            </div>

            <button 
              onClick={simulatePayment}
              disabled={isSimulating}
              className="mt-6 nav-pill w-full flex items-center justify-center gap-2 border-dashed border-[var(--color-v3-outline)] bg-transparent hover:bg-[var(--color-v3-surface-container-high)] text-[var(--color-v3-text-var)] hover:text-white transition-all py-3 group/sim"
            >
              <ExternalLink className="w-4 h-4 group-hover/sim:text-[var(--color-v3-accent)] transition-colors" />
              {isSimulating ? 'Simulating...' : 'Simulate Successful Payment'}
            </button>
          </div>
        </motion.div>
      </div>

      {/* Recent Transactions Section */}
      <div className="max-w-7xl mx-auto mt-32 relative z-10">
        <motion.div
           initial={{ opacity: 0, y: 20 }}
           whileInView={{ opacity: 1, y: 0 }}
           viewport={{ once: true }}
           className="glass-border rounded-[2.5rem] p-8 md:p-12 relative overflow-hidden"
        >
          <div className="absolute top-0 left-0 w-64 h-64 bg-indigo-500/5 rounded-full blur-3xl -z-10 -translate-x-1/2 -translate-y-1/2" />
          
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-6">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-[var(--color-v3-text)] mb-2">Recent Transactions</h2>
              <p className="text-[var(--color-v3-text-var)] font-light text-lg">A record of past successful payments.</p>
            </div>
            <div className="text-sm font-medium text-[var(--color-v3-text-var)] px-4 py-2 rounded-full border border-[var(--color-v3-outline)] bg-[var(--color-v3-surface-container)]">
              Real-time API Sync
            </div>
          </div>

          <div className="overflow-x-auto">
            {loading ? (
              <div className="flex justify-center items-center py-16">
                <div className="w-8 h-8 border-2 border-[var(--color-v3-accent)] border-t-transparent rounded-full animate-spin"></div>
              </div>
            ) : transactions.length > 0 ? (
              <table className="w-full text-left border-collapse min-w-[600px]">
                <thead>
                  <tr className="border-b border-[var(--color-v3-outline)]">
                    <th className="pb-4 font-medium text-[var(--color-v3-text-var)] uppercase tracking-wider text-sm">Date</th>
                    <th className="pb-4 font-medium text-[var(--color-v3-text-var)] uppercase tracking-wider text-sm">Description</th>
                    <th className="pb-4 font-medium text-[var(--color-v3-text-var)] uppercase tracking-wider text-sm text-right">Amount</th>
                  </tr>
                </thead>
                <tbody>
                  {transactions.map((tx, idx) => (
                    <motion.tr 
                      key={tx.id}
                      initial={{ opacity: 0, y: 10 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: idx * 0.1 }}
                      className="border-b border-[var(--color-v3-outline)]/50 hover:bg-[var(--color-v3-surface-container)]/50 transition-colors group"
                    >
                      <td className="py-5 font-light text-[var(--color-v3-text-var)]">
                        <div className="flex items-center gap-2">
                           <Calendar className="w-4 h-4 opacity-50" />
                           {new Date(tx.date).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })}
                        </div>
                      </td>
                      <td className="py-5 text-[var(--color-v3-text)] font-medium">
                        {tx.description}
                      </td>
                      <td className="py-5 text-right font-medium text-[var(--color-v3-text)]">
                        <div className="flex items-center justify-end gap-1">
                          <span className="text-emerald-400 group-hover:text-emerald-300 transition-colors">₹{tx.amount.toFixed(2)}</span>
                        </div>
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            ) : (
               <div className="py-16 text-center flex flex-col items-center">
                  <HandCoins className="w-12 h-12 text-[var(--color-v3-outline)] mb-4" />
                  <p className="text-[var(--color-v3-text-var)] font-light text-lg">No transactions yet. Your payment history will appear here after successful payments.</p>
               </div>
            )}
          </div>
        </motion.div>
      </div>
    </div>
    </>
  );
}
