import { motion } from 'motion/react';
import SEO from '../components/SEO';
import AboutScene from '../components/3d/AboutScene';

const skills = [
  { name: 'TypeScript / JavaScript', level: 95 },
  { name: 'React / Next.js', level: 90 },
  { name: 'UI/UX Design', level: 85 },
  { name: 'Three.js / WebGL', level: 75 },
  { name: 'Node.js / Backend', level: 80 }
];

export default function About() {
  return (
    <>
    <SEO title="About" description="Learn more about Harsh and HS Studio." />
    <div className="pt-12 pb-24 px-6 relative">
      <div className="absolute top-20 right-0 w-full md:w-1/2 h-[500px] z-0 opacity-50 ">
         <AboutScene />
      </div>
      <div className="max-w-7xl mx-auto relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-3xl mb-24"
        >
          <div className="small-caps mb-6 text-[var(--color-v3-accent)] tracking-widest bg-[var(--color-v3-accent)]/10 px-4 py-1.5 rounded-full inline-block border border-[var(--color-v3-accent)]/20">About Me</div>
          <h1 className="text-5xl md:text-7xl font-bold tracking-tighter mb-8 text-[var(--color-v3-text)]">
            I am Harsh, a builder, <br /><span className="text-gradient italic font-light">thinker & creator.</span>
          </h1>
          <p className="text-xl text-[var(--color-v3-text-var)] font-light leading-relaxed">
            HS Studio was founded by Harsh Singh with a simple mission: to create digital experiences that are both beautiful and highly functional. Based in Balrampur, India — I work with clients across the country to build stunning websites, apps, and digital products.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
            className="relative aspect-square lg:aspect-[4/5] rounded-[2rem] overflow-hidden glass-border p-3 group"
          >
            <div className="absolute inset-0 bg-gradient-to-tr from-[var(--color-v3-accent)] to-[var(--color-v3-accent-4)] opacity-20 blur-3xl -z-10 group-hover:opacity-40 transition-opacity duration-500" />
            <div className="w-full h-full rounded-2xl overflow-hidden relative">
              <img 
                src="https://images.unsplash.com/photo-1555952517-2e8e729e0b44?auto=format&fit=crop&q=80&w=1000" 
                alt="Profile Workspace"
                className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-all duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 ring-1 ring-inset ring-white/10 rounded-2xl pointer-events-none" />
            </div>
          </motion.div>

          <div className="flex flex-col gap-12 pt-4">
            <motion.div
               initial={{ opacity: 0, x: 20 }}
               whileInView={{ opacity: 1, x: 0 }}
               viewport={{ once: true }}
               className="glass-border p-8 rounded-3xl"
            >
              <h3 className="text-2xl font-semibold text-[var(--color-v3-text)] mb-4">My Mission & Vision</h3>
              <p className="text-[var(--color-v3-text-var)] font-light leading-relaxed">
                To empower businesses through thoughtful design and robust engineering. My goal is to build digital products that are fast, beautiful, and easy to use — helping businesses grow online.
              </p>
            </motion.div>

            <motion.div
               initial={{ opacity: 0, x: 20 }}
               whileInView={{ opacity: 1, x: 0 }}
               viewport={{ once: true }}
               transition={{ delay: 0.1 }}
               className="glass-border p-8 rounded-3xl"
            >
              <h3 className="text-2xl font-semibold text-[var(--color-v3-text)] mb-6">Skills & Expertise</h3>
              <div className="space-y-6">
                {skills.map((skill, index) => (
                  <div key={index}>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm font-medium text-[var(--color-v3-text)]">{skill.name}</span>
                      <span className="text-sm font-medium text-[var(--color-v3-accent)]">{skill.level}%</span>
                    </div>
                    <div className="h-2 bg-[var(--color-v3-surface-container-highest)] rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        whileInView={{ width: `${skill.level}%` }}
                        viewport={{ once: true }}
                        transition={{ duration: 1, delay: 0.3 + (index * 0.1), ease: "easeOut" }}
                        className="h-full bg-gradient-to-r from-[var(--color-v3-accent)] to-[var(--color-v3-accent-4)] relative"
                      >
                        <div className="absolute inset-0 bg-white/20 w-full h-full animate-[shimmer_2s_infinite]" style={{ transform: 'translateX(-100%)' }}></div>
                      </motion.div>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
            
            <div className="pt-8 border-t border-[var(--color-v3-outline)]">
              <div className="grid grid-cols-2 gap-8 mb-8">
                <div>
                   <div className="text-5xl font-bold text-gradient mb-2">2+</div>
                   <div className="text-[var(--color-v3-text-var)] text-sm uppercase tracking-wider font-medium">Years Experience</div>
                </div>
                <div>
                   <div className="text-5xl font-bold text-gradient mb-2">20+</div>
                   <div className="text-[var(--color-v3-text-var)] text-sm uppercase tracking-wider font-medium">Projects Completed</div>
                </div>
              </div>

              <div className="glass-border p-6 rounded-2xl bg-[var(--color-v3-surface-container)]/30 space-y-3">
                 <div className="flex items-center gap-3 text-[var(--color-v3-text-var)] hover:text-white transition-colors">
                    <span className="text-xl">📧</span>
                    <a href="mailto:singhharsh68536@gmail.com" className="font-light">singhharsh68536@gmail.com</a>
                 </div>
                 <div className="flex items-center gap-3 text-[var(--color-v3-text-var)] hover:text-white transition-colors">
                    <span className="text-xl">📞</span>
                    <a href="tel:+919098495546" className="font-light">+91 9098495546</a>
                 </div>
                 <div className="flex items-center gap-3 text-[var(--color-v3-text-var)] hover:text-white transition-colors">
                    <span className="text-xl">📍</span>
                    <span className="font-light">Balrampur, India</span>
                 </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    </>
  );
}
