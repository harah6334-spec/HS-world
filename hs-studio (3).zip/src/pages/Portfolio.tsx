import { motion, AnimatePresence } from 'motion/react';
import { ArrowUpRight, Eye } from 'lucide-react';
import { useState } from 'react';
import SEO from '../components/SEO';
import TiltCard from '../components/3d/TiltCard';

const categories = ["All", "UI/UX & Engineering", "Full-Stack Development", "Brand & Web Design", "Web Development"];

const projects = [
  {
    id: 1,
    title: "FinTech Dashboard",
    category: "UI/UX & Engineering",
    desc: "A complete financial analytics dashboard with real-time charts, dark mode, and role-based access control.",
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&q=80&w=2070",
    color: "from-[var(--color-v3-accent)]/80"
  },
  {
    id: 2,
    title: "Enterprise Web Application",
    category: "Full-Stack Development",
    desc: "Full-stack business management app with React frontend, Node.js backend, and PostgreSQL database.",
    image: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&q=80&w=2034",
    color: "from-emerald-500/80"
  },
  {
    id: 3,
    title: "Creative Agency Website",
    category: "Brand & Web Design",
    desc: "Complete brand identity + website redesign for a creative agency. New logo, colors, and a fast React website.",
    image: "https://images.unsplash.com/photo-1561070791-2526d30994b5?auto=format&fit=crop&q=80&w=2000",
    color: "from-purple-500/80"
  },
  {
    id: 4,
    title: "Real Estate Platform",
    category: "Web Development",
    desc: "Property listing website with search filters, map integration, and an admin panel for managing listings.",
    image: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&q=80&w=2072",
    color: "from-amber-500/80"
  }
];

export default function Portfolio() {
  const [activeCategory, setActiveCategory] = useState("All");

  const filteredProjects = projects.filter(
    (project) => activeCategory === "All" || project.category === activeCategory
  );

  return (
    <>
    <SEO title="Portfolio" description="Selected case studies and projects by HS Studio." />
    <div className="pt-12 pb-24 px-6">
      <div className="max-w-7xl mx-auto">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-3xl mb-16"
        >
          <div className="small-caps mb-6 text-[var(--color-v3-accent)] tracking-widest bg-[var(--color-v3-accent)]/10 px-4 py-1.5 rounded-full inline-block border border-[var(--color-v3-accent)]/20 shadow-[0_0_15px_rgba(99,102,241,0.2)]">Selected Work</div>
          <h1 className="text-5xl md:text-7xl font-bold tracking-tighter mb-8 text-[var(--color-v3-text)]">
            Proof of <span className="text-gradient italic font-light">craft.</span>
          </h1>
          <p className="text-xl text-[var(--color-v3-text-var)] font-light leading-relaxed">
            Here are some of the projects I have built for clients — from dashboards to full websites to mobile apps. Each project is built with care, performance, and design in mind.
          </p>
        </motion.div>

        {/* Filters */}
        <div className="flex flex-wrap gap-4 mb-20">
          {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`relative px-6 py-2.5 rounded-full text-sm font-medium transition-all duration-300 border ${
                  activeCategory === cat 
                    ? 'border-transparent text-white shadow-[0_0_20px_rgba(99,102,241,0.4)]' 
                    : 'bg-[var(--color-v3-surface-container-highest)] text-[var(--color-v3-text-var)] border-[var(--color-v3-outline)] hover:text-white hover:border-white/20'
                }`}
             >
                {activeCategory === cat && (
                  <motion.div
                    layoutId="activeFilterBg"
                    className="absolute inset-0 bg-[var(--color-v3-accent)] rounded-full -z-10"
                    transition={{ type: "spring", stiffness: 350, damping: 25 }}
                  />
                )}
                <span className="relative z-10">{cat}</span>
             </button>
          ))}
        </div>

        <div className="flex flex-col gap-32">
          <AnimatePresence mode="popLayout">
            {filteredProjects.map((project, i) => (
              <motion.div 
                layout
                key={project.id}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.5 }}
                className="group cursor-pointer"
                style={{ perspective: 1000 }}
              >
                <TiltCard>
                  <div className="relative aspect-video md:aspect-[21/9] rounded-[2rem] overflow-hidden glass-border mb-8 group/card ring-1 ring-white/10 group-hover:ring-[var(--color-v3-accent)]/50 transition-all duration-500 group-hover:shadow-[0_0_30px_rgba(99,102,241,0.2)]">
                    <img 
                      src={project.image} 
                      alt={project.title}
                      className="w-full h-full object-cover opacity-80 group-hover/card:opacity-100 group-hover/card:scale-105 transition-all duration-700 ease-out"
                    />
                    
                    {/* Hover Overlay */}
                    <div className="absolute inset-0 bg-gradient-to-t from-[var(--color-v3-surface)]/90 via-transparent to-transparent opacity-0 group-hover/card:opacity-100 transition-opacity duration-500 flex flex-col justify-end p-8 md:p-12">
                      <div className="translate-y-8 group-hover/card:translate-y-0 transition-transform duration-500 ease-out">
                         <div className="nav-pill primary !border-transparent inline-flex items-center gap-2 mb-4">
                            <Eye className="w-4 h-4" /> View Project
                         </div>
                      </div>
                    </div>
                  </div>
                </TiltCard>
                <div className="flex justify-between items-start">
                  <div className="max-w-2xl">
                    <h3 className="text-3xl font-bold text-[var(--color-v3-text)] mb-3 group-hover:text-gradient transition-colors">{project.title}</h3>
                    <p className="text-[var(--color-v3-accent)] uppercase tracking-wider text-sm font-medium mb-3">{project.category}</p>
                    <p className="text-[var(--color-v3-text-var)] text-lg font-light">{project.desc}</p>
                  </div>
                  <div className="w-14 h-14 rounded-full border border-[var(--color-v3-outline)] flex items-center justify-center text-[var(--color-v3-text)] group-hover:bg-[var(--color-v3-accent)] group-hover:text-white group-hover:border-[var(--color-v3-accent)] group-hover:shadow-[0_0_20px_rgba(99,102,241,0.4)] transition-all duration-300 shrink-0 ml-4">
                     <ArrowUpRight className="w-6 h-6 group-hover:scale-110 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </div>
    </div>
    </>
  );
}
