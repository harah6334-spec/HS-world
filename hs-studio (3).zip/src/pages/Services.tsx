import { motion } from 'motion/react';
import { Layout, Code, PenTool, Search, Smartphone, Server } from 'lucide-react';
import { Link } from 'react-router-dom';
import SEO from '../components/SEO';
import WireframeTorusScene from '../components/3d/WireframeTorus';

export default function Services() {
  const services = [
    { 
      icon: Layout, 
      title: "UI/UX Design", 
      desc: "Beautiful, user-friendly designs that look great and work even better. I build design systems, wireframes, and prototypes for web and mobile apps.",
      image: "https://images.unsplash.com/photo-1561070791-2526d30994b5?auto=format&fit=crop&q=80&w=2000"
    },
    { 
      icon: Code, 
      title: "Web Development", 
      desc: "Fast, modern websites built with React, Next.js, and Tailwind CSS. Custom built to match your brand and business goals.",
      image: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&q=80&w=2072"
    },
    { 
      icon: Server, 
      title: "Full Stack Development", 
      desc: "Complete web applications with frontend + backend + database. Built with Node.js, Express, and cloud deployment on platforms like Vercel and Google Cloud.",
      image: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&q=80&w=2034"
    },
    { 
      icon: Smartphone, 
      title: "Mobile Apps", 
      desc: "Cross-platform mobile apps for Android and iOS using React Native. Same codebase, native-like performance.",
      image: "https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?auto=format&fit=crop&q=80&w=2070"
    },
    { 
      icon: Search, 
      title: "SEO Optimization", 
      desc: "Technical SEO, page speed optimization, and on-page SEO to make sure your website ranks on Google and gets real traffic.",
      image: "https://images.unsplash.com/photo-1432888498266-38ffec3eaf0a?auto=format&fit=crop&q=80&w=2074"
    },
    { 
      icon: PenTool, 
      title: "Brand Identity", 
      desc: "Logo design, color palette, typography, and brand guidelines — everything you need to look professional and memorable.",
      image: "https://images.unsplash.com/photo-1542744094-3a31f272c490?auto=format&fit=crop&q=80&w=2070"
    },
  ];

  return (
    <>
    <SEO title="Services" description="Explore the digital design and development services we offer." />
    <div className="pt-12 pb-24 relative">
      <div className="absolute top-0 right-0 w-full md:w-1/2 h-[400px] z-0 opacity-50 ">
         <WireframeTorusScene />
      </div>
      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-3xl mb-24 pt-12 md:pt-24"
        >
          <div className="small-caps mb-6 text-[var(--color-v3-accent)] tracking-widest bg-[var(--color-v3-accent)]/10 px-4 py-1.5 rounded-full inline-block border border-[var(--color-v3-accent)]/20 shadow-[0_0_15px_rgba(99,102,241,0.2)]">Capabilities</div>
          <h1 className="text-5xl md:text-7xl font-bold tracking-tighter mb-8 text-[var(--color-v3-text)]">
            What I <span className="text-gradient italic font-light">do well.</span>
          </h1>
          <p className="text-xl text-[var(--color-v3-text-var)] font-light leading-relaxed">
            I provide complete end-to-end digital services for businesses and startups. From initial brand strategy to final deployment — I handle every aspect of your digital presence. Contact me at singhharsh68536@gmail.com or call +91 9098495546
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((svc, i) => (
            <Link to="/contact" key={i}>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ margin: "-50px", once: true }}
                transition={{ delay: i * 0.1 }}
                className="glass-border rounded-[2rem] overflow-hidden bg-[var(--color-v3-surface-container)] hover:shadow-[0_0_30px_rgba(99,102,241,0.2)] hover:border-[var(--color-v3-accent)]/50 transition-all duration-500 group cursor-pointer flex flex-col h-full transform hover:-translate-y-2 relative"
              >
                <div className="absolute inset-0 bg-gradient-to-b from-transparent to-[var(--color-v3-accent)]/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500 z-0"></div>
                
                <div className="relative h-56 w-full overflow-hidden z-10">
                  <div className="absolute inset-0 bg-[var(--color-v3-accent)]/20 mix-blend-overlay opacity-0 group-hover:opacity-100 transition-opacity duration-500 z-10"></div>
                  <img 
                    src={svc.image} 
                    alt={svc.title} 
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 ease-out opacity-80 group-hover:opacity-100"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[var(--color-v3-surface-container)] via-transparent to-transparent opacity-80"></div>
                  <div className="absolute bottom-6 left-6 w-14 h-14 rounded-2xl glass-border flex items-center justify-center text-white bg-black/40 backdrop-blur-md group-hover:scale-110 group-hover:bg-[var(--color-v3-accent)] group-hover:border-transparent group-hover:shadow-[0_0_15px_rgba(99,102,241,0.5)] transition-all duration-500">
                    <svc.icon className="w-6 h-6" />
                  </div>
                </div>

                <div className="p-8 flex-grow flex flex-col relative z-10">
                  <h3 className="text-2xl font-bold text-[var(--color-v3-text)] mb-3 group-hover:text-gradient transition-all duration-300">{svc.title}</h3>
                  <p className="text-[var(--color-v3-text-var)] font-light leading-relaxed group-hover:text-[var(--color-v3-text)] transition-colors duration-300">
                    {svc.desc}
                  </p>
                </div>
              </motion.div>
            </Link>
          ))}
        </div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-32 p-12 md:p-16 rounded-[3rem] glass-border bg-gradient-to-br from-[var(--color-v3-surface-container)] to-[var(--color-v3-surface-container-high)] text-center relative overflow-hidden group"
        >
          <div className="absolute inset-0 bg-gradient-to-r from-[var(--color-v3-accent)]/0 via-[var(--color-v3-accent)]/5 to-[var(--color-v3-accent-4)]/0 opacity-0 group-hover:opacity-100 transition-opacity duration-700 animate-[shimmer_3s_infinite] -translate-x-full"></div>
          <div className="relative z-10">
            <h2 className="text-4xl md:text-5xl font-bold text-[var(--color-v3-text)] mb-6">Ready to start your project?</h2>
            <p className="text-xl text-[var(--color-v3-text-var)] font-light mb-10 max-w-2xl mx-auto">Let's build something great together. Reach out at singhharsh68536@gmail.com or call +91 9098495546</p>
            <Link to="/contact" className="nav-pill primary !px-10 !py-4 text-lg inline-flex items-center gap-2">
              Start a conversation <Search className="w-5 h-5 ml-2" />
            </Link>
          </div>
        </motion.div>
      </div>
    </div>
    </>
  );
}
