import { motion, AnimatePresence } from 'motion/react';
import { User, Lock, Mail, Eye, EyeOff, LogIn, CheckCircle2, UserPlus } from 'lucide-react';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import SEO from '../components/SEO';
import ContactScene from '../components/3d/ContactScene';

export default function Login() {
  const [isLoginView, setIsLoginView] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({ name: '', email: '', password: '', confirmPassword: '' });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error' | null; message: string }>({ type: null, message: '' });
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.id]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setFeedback({ type: null, message: '' });
    
    if (!isLoginView && formData.password !== formData.confirmPassword) {
      setFeedback({ type: 'error', message: 'Passwords do not match.' });
      setIsSubmitting(false);
      return;
    }

    try {
      const endpoint = isLoginView ? '/api/login' : '/api/register';
      const body = isLoginView 
        ? { email: formData.email, password: formData.password }
        : { name: formData.name, email: formData.email, password: formData.password };
        
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(body),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Something went wrong');
      }

      setFeedback({ type: 'success', message: `Successfully ${isLoginView ? 'logged in' : 'registered'}!` });
      login(data.user);
      
      // Redirect to home after a brief delay
      setTimeout(() => {
        navigate('/');
      }, 1000);
      
    } catch (error: any) {
      setFeedback({ type: 'error', message: error.message });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <>
    <SEO title={isLoginView ? "Login" : "Register"} description="Access your HS Studio account." />
    <div className="pt-12 pb-24 px-6 relative min-h-screen">
      <div className="absolute top-1/4 left-0 md:left-1/4 w-full md:w-3/4 h-[800px] z-0 opacity-40 pointer-events-none">
         <ContactScene />
      </div>
      <div className="max-w-md mx-auto relative z-10 pt-16">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="glass-border rounded-[2.5rem] p-8 md:p-12 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-[var(--color-v3-accent)]/10 rounded-full blur-3xl -z-10 translate-x-1/3 -translate-y-1/3" />
            
            <div className="flex gap-4 mb-10 bg-[var(--color-v3-surface-container)]/50 p-1 rounded-full border border-[var(--color-v3-outline)]">
              <button 
                onClick={() => { setIsLoginView(true); setFeedback({type: null, message: ''}); }}
                className={`flex-1 py-2.5 rounded-full text-sm font-medium transition-all ${isLoginView ? 'bg-[var(--color-v3-accent)] text-white shadow-md' : 'text-[var(--color-v3-text-var)] hover:text-white'}`}
              >
                Login
              </button>
              <button 
                onClick={() => { setIsLoginView(false); setFeedback({type: null, message: ''}); }}
                className={`flex-1 py-2.5 rounded-full text-sm font-medium transition-all ${!isLoginView ? 'bg-[var(--color-v3-accent)] text-white shadow-md' : 'text-[var(--color-v3-text-var)] hover:text-white'}`}
              >
                Register
              </button>
            </div>

            <div className="text-center mb-10">
               <h1 className="text-3xl font-bold tracking-tighter mb-2 text-[var(--color-v3-text)]">
                 {isLoginView ? 'Welcome ' : 'Create '}
                 <span className="text-gradient italic font-light">{isLoginView ? 'back' : 'account'}</span>
               </h1>
               <p className="text-[var(--color-v3-text-var)] font-light">
                 {isLoginView ? 'Enter your details to sign in.' : 'Get started with an account.'}
               </p>
            </div>

            <form className="flex flex-col gap-6 relative z-10" onSubmit={handleSubmit}>
              <AnimatePresence mode="popLayout">
                {!isLoginView && (
                  <motion.div 
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="relative group/input"
                  >
                    <div className="absolute left-0 top-4 text-[var(--color-v3-text-var)] peer-focus:text-[var(--color-v3-accent)] transition-colors">
                       <User className="w-5 h-5" />
                    </div>
                    <input 
                      type="text" 
                      id="name" 
                      value={formData.name}
                      onChange={handleChange}
                      disabled={isSubmitting}
                      required={!isLoginView}
                      className="peer w-full bg-transparent border-b-2 border-white/10 pl-10 pr-0 py-4 text-white placeholder-transparent focus:outline-none focus:border-[var(--color-v3-accent)] transition-colors duration-300 font-light"
                      placeholder="Name"
                    />
                    <label htmlFor="name" className="absolute left-10 top-0 py-4 text-[var(--color-v3-text-var)] cursor-text peer-focus:-translate-y-6 peer-focus:scale-75 peer-focus:text-[var(--color-v3-accent)] peer-valid:-translate-y-6 peer-valid:scale-75 transition-all duration-300 origin-left">Name</label>
                    <div className="absolute bottom-0 left-0 h-[2px] w-0 bg-gradient-to-r from-[var(--color-v3-accent)] to-[var(--color-v3-accent-4)] peer-focus:w-full transition-all duration-500 ease-out" />
                  </motion.div>
                )}
              </AnimatePresence>

              <div className="relative group/input">
                <div className="absolute left-0 top-4 text-[var(--color-v3-text-var)] peer-focus:text-[var(--color-v3-accent)] transition-colors">
                   <Mail className="w-5 h-5" />
                </div>
                <input 
                  type="email" 
                  id="email" 
                  value={formData.email}
                  onChange={handleChange}
                  disabled={isSubmitting}
                  required
                  className="peer w-full bg-transparent border-b-2 border-white/10 pl-10 pr-0 py-4 text-white placeholder-transparent focus:outline-none focus:border-[var(--color-v3-accent)] transition-colors duration-300 font-light"
                  placeholder="Email"
                />
                <label htmlFor="email" className="absolute left-10 top-0 py-4 text-[var(--color-v3-text-var)] cursor-text peer-focus:-translate-y-6 peer-focus:scale-75 peer-focus:text-[var(--color-v3-accent)] peer-valid:-translate-y-6 peer-valid:scale-75 transition-all duration-300 origin-left">Email address</label>
                <div className="absolute bottom-0 left-0 h-[2px] w-0 bg-gradient-to-r from-[var(--color-v3-accent)] to-[var(--color-v3-accent-4)] peer-focus:w-full transition-all duration-500 ease-out" />
              </div>

              <div className="relative group/input">
                <div className="absolute left-0 top-4 text-[var(--color-v3-text-var)] peer-focus:text-[var(--color-v3-accent)] transition-colors">
                   <Lock className="w-5 h-5" />
                </div>
                <input 
                  type={showPassword ? 'text' : 'password'} 
                  id="password" 
                  value={formData.password}
                  onChange={handleChange}
                  disabled={isSubmitting}
                  required
                  className="peer w-full bg-transparent border-b-2 border-white/10 pl-10 pr-10 py-4 text-white placeholder-transparent focus:outline-none focus:border-[var(--color-v3-accent)] transition-colors duration-300 font-light"
                  placeholder="Password"
                />
                <label htmlFor="password" className="absolute left-10 top-0 py-4 text-[var(--color-v3-text-var)] cursor-text peer-focus:-translate-y-6 peer-focus:scale-75 peer-focus:text-[var(--color-v3-accent)] peer-valid:-translate-y-6 peer-valid:scale-75 transition-all duration-300 origin-left">Password</label>
                <div className="absolute bottom-0 left-0 h-[2px] w-0 bg-gradient-to-r from-[var(--color-v3-accent)] to-[var(--color-v3-accent-4)] peer-focus:w-full transition-all duration-500 ease-out" />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-0 top-4 text-[var(--color-v3-text-var)] hover:text-white transition-colors"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>

              <AnimatePresence mode="popLayout">
                {!isLoginView && (
                  <motion.div 
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="relative group/input"
                  >
                    <div className="absolute left-0 top-4 text-[var(--color-v3-text-var)] peer-focus:text-[var(--color-v3-accent)] transition-colors">
                       <Lock className="w-5 h-5" />
                    </div>
                    <input 
                      type={showPassword ? 'text' : 'password'} 
                      id="confirmPassword" 
                      value={formData.confirmPassword}
                      onChange={handleChange}
                      disabled={isSubmitting}
                      required={!isLoginView}
                      className="peer w-full bg-transparent border-b-2 border-white/10 pl-10 pr-0 py-4 text-white placeholder-transparent focus:outline-none focus:border-[var(--color-v3-accent)] transition-colors duration-300 font-light"
                      placeholder="Confirm Password"
                    />
                    <label htmlFor="confirmPassword" className="absolute left-10 top-0 py-4 text-[var(--color-v3-text-var)] cursor-text peer-focus:-translate-y-6 peer-focus:scale-75 peer-focus:text-[var(--color-v3-accent)] peer-valid:-translate-y-6 peer-valid:scale-75 transition-all duration-300 origin-left">Confirm Password</label>
                    <div className="absolute bottom-0 left-0 h-[2px] w-0 bg-gradient-to-r from-[var(--color-v3-accent)] to-[var(--color-v3-accent-4)] peer-focus:w-full transition-all duration-500 ease-out" />
                  </motion.div>
                )}
              </AnimatePresence>

              <AnimatePresence>
                {feedback.type && (
                  <motion.div 
                    initial={{ opacity: 0, height: 0, scale: 0.9 }}
                    animate={{ opacity: 1, height: 'auto', scale: 1 }}
                    exit={{ opacity: 0, height: 0, scale: 0.9 }}
                    className={`py-3 px-4 rounded-xl text-sm flex items-center gap-3 mt-2 ${feedback.type === 'success' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-red-500/10 text-red-500 border border-red-500/20'}`}
                  >
                    {feedback.type === 'success' && <CheckCircle2 className="w-5 h-5 flex-shrink-0" />}
                    {feedback.message}
                  </motion.div>
                )}
              </AnimatePresence>

              <button 
                type="submit"
                disabled={isSubmitting}
                className="nav-pill primary block w-full text-center py-4 mt-8 disabled:opacity-70 disabled:cursor-not-allowed group/btn overflow-hidden relative"
              >
                <span className="relative z-10 flex items-center justify-center gap-2 text-lg">
                  {isLoginView ? <LogIn className="w-5 h-5" /> : <UserPlus className="w-5 h-5" />}
                  {isSubmitting ? 'Processing...' : isLoginView ? 'Sign In' : 'Create Account'}
                </span>
                <div className="absolute inset-0 bg-gradient-to-r from-[var(--color-v3-accent-4)] to-[var(--color-v3-accent)] opacity-0 group-hover/btn:opacity-100 transition-opacity duration-300" />
              </button>
            </form>
          </div>
        </motion.div>
      </div>
    </div>
    </>
  );
}
