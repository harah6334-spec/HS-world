import { motion, AnimatePresence } from 'motion/react';
import { Mail, MapPin, Phone, Loader2, CheckCircle2 } from 'lucide-react';
import { useState } from 'react';
import SEO from '../components/SEO';
import ContactScene from '../components/3d/ContactScene';

export default function Contact() {
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error' | null, message: string }>({ type: null, message: '' });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setFeedback({ type: null, message: '' });

    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Something went wrong.');
      }

      setFeedback({ type: 'success', message: data.message });
      setFormData({ name: '', email: '', message: '' });
      setTimeout(() => setFeedback({ type: null, message: '' }), 5000);
    } catch (error: any) {
      setFeedback({ type: 'error', message: error.message });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({ ...prev, [e.target.id]: e.target.value }));
  };

  return (
    <>
    <SEO title="Contact" description="Get in touch with HS Studio for your next project." />
    <div className="pt-12 pb-24 px-6 relative">
      <div className="absolute top-1/4 left-0 md:left-1/4 w-full md:w-3/4 h-[800px] z-0 opacity-40 ">
         <ContactScene />
      </div>
      <div className="max-w-7xl mx-auto flex flex-col lg:flex-row gap-16 lg:gap-24 relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full lg:w-1/2"
        >
          <div className="small-caps mb-6 text-[var(--color-v3-accent)] tracking-widest bg-[var(--color-v3-accent)]/10 px-4 py-1.5 rounded-full inline-block border border-[var(--color-v3-accent)]/20 shadow-[0_0_15px_rgba(99,102,241,0.2)]">Get in touch</div>
          <h1 className="text-5xl md:text-7xl font-bold tracking-tighter mb-8 text-[var(--color-v3-text)]">
            Let's build <br /><span className="text-gradient italic font-light">together.</span>
          </h1>
          <p className="text-xl text-[var(--color-v3-text-var)] font-light leading-relaxed mb-16">
            Have a project in mind? Fill out the form or drop an email. We typically respond within 24 hours.
          </p>

          <div className="flex flex-col gap-10">
            <div className="flex items-center gap-6 text-[var(--color-v3-text)] group">
               <div className="w-16 h-16 rounded-2xl glass-border flex items-center justify-center text-[var(--color-v3-accent)] group-hover:scale-110 group-hover:shadow-[0_0_20px_rgba(99,102,241,0.3)] transition-all duration-300 relative overflow-hidden">
                 <div className="absolute inset-0 bg-gradient-to-br from-[var(--color-v3-accent)]/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                 <Mail className="w-6 h-6 relative z-10 group-hover:text-[var(--color-v3-text)] transition-colors" />
               </div>
               <div>
                  <div className="text-sm font-medium text-[var(--color-v3-text-var)] mb-1 uppercase tracking-wider">Email</div>
                  <div className="text-xl font-medium">singhharsh68536@gmail.com</div>
               </div>
            </div>
            <div className="flex items-center gap-6 text-[var(--color-v3-text)] group">
               <div className="w-16 h-16 rounded-2xl glass-border flex items-center justify-center text-[var(--color-v3-accent)] group-hover:scale-110 group-hover:shadow-[0_0_20px_rgba(99,102,241,0.3)] transition-all duration-300 relative overflow-hidden">
                 <div className="absolute inset-0 bg-gradient-to-br from-[var(--color-v3-accent)]/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                 <Phone className="w-6 h-6 relative z-10 group-hover:text-[var(--color-v3-text)] transition-colors" />
               </div>
               <div>
                  <div className="text-sm font-medium text-[var(--color-v3-text-var)] mb-1 uppercase tracking-wider">Phone</div>
                  <div className="text-xl font-medium">+91 9098495546</div>
               </div>
            </div>
            <div className="flex items-center gap-6 text-[var(--color-v3-text)] group">
               <div className="w-16 h-16 rounded-2xl glass-border flex items-center justify-center text-[var(--color-v3-accent)] group-hover:scale-110 group-hover:shadow-[0_0_20px_rgba(99,102,241,0.3)] transition-all duration-300 relative overflow-hidden">
                 <div className="absolute inset-0 bg-gradient-to-br from-[var(--color-v3-accent)]/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                 <MapPin className="w-6 h-6 relative z-10 group-hover:text-[var(--color-v3-text)] transition-colors" />
               </div>
               <div>
                  <div className="text-sm font-medium text-[var(--color-v3-text-var)] mb-1 uppercase tracking-wider">Location</div>
                  <div className="text-xl font-medium">Balrampur, India</div>
               </div>
            </div>
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
          className="w-full lg:w-1/2"
        >
          <div className="glass-border rounded-[2.5rem] p-8 md:p-12 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-[var(--color-v3-accent)]/10 rounded-full blur-3xl -z-10 translate-x-1/3 -translate-y-1/3" />
            <form className="flex flex-col gap-8 relative z-10" onSubmit={handleSubmit}>
              <div className="relative group/input">
                <input 
                  type="text" 
                  id="name" 
                  value={formData.name}
                  onChange={handleChange}
                  disabled={isSubmitting}
                  required
                  className="peer w-full bg-transparent border-b-2 border-white/10 px-0 py-4 text-white placeholder-transparent focus:outline-none focus:border-[var(--color-v3-accent)] transition-colors duration-300 font-light"
                  placeholder="Name"
                />
                <label htmlFor="name" className="absolute left-0 top-0 py-4 text-[var(--color-v3-text-var)] cursor-text peer-focus:-translate-y-6 peer-focus:scale-75 peer-focus:text-[var(--color-v3-accent)] peer-valid:-translate-y-6 peer-valid:scale-75 transition-all duration-300 origin-left">Name</label>
                <div className="absolute bottom-0 left-0 h-[2px] w-0 bg-gradient-to-r from-[var(--color-v3-accent)] to-[var(--color-v3-accent-4)] peer-focus:w-full transition-all duration-500 ease-out" />
              </div>
              
              <div className="relative group/input">
                <input 
                  type="email" 
                  id="email" 
                  value={formData.email}
                  onChange={handleChange}
                  disabled={isSubmitting}
                  required
                  className="peer w-full bg-transparent border-b-2 border-white/10 px-0 py-4 text-white placeholder-transparent focus:outline-none focus:border-[var(--color-v3-accent)] transition-colors duration-300 font-light"
                  placeholder="Email"
                />
                <label htmlFor="email" className="absolute left-0 top-0 py-4 text-[var(--color-v3-text-var)] cursor-text peer-focus:-translate-y-6 peer-focus:scale-75 peer-focus:text-[var(--color-v3-accent)] peer-valid:-translate-y-6 peer-valid:scale-75 transition-all duration-300 origin-left">Email address</label>
                <div className="absolute bottom-0 left-0 h-[2px] w-0 bg-gradient-to-r from-[var(--color-v3-accent)] to-[var(--color-v3-accent-4)] peer-focus:w-full transition-all duration-500 ease-out" />
              </div>

              <div className="relative group/input mt-4">
                <textarea 
                  id="message" 
                  rows={4}
                  value={formData.message}
                  onChange={handleChange}
                  disabled={isSubmitting}
                  required
                  className="peer w-full bg-transparent border-b-2 border-white/10 px-0 py-4 text-white placeholder-transparent focus:outline-none focus:border-[var(--color-v3-accent)] transition-colors duration-300 font-light resize-none"
                  placeholder="Message"
                ></textarea>
                <label htmlFor="message" className="absolute left-0 top-0 py-4 text-[var(--color-v3-text-var)] cursor-text peer-focus:-translate-y-6 peer-focus:scale-75 peer-focus:text-[var(--color-v3-accent)] peer-valid:-translate-y-6 peer-valid:scale-75 transition-all duration-300 origin-left">Tell me about your project</label>
                <div className="absolute bottom-0 left-0 h-[2px] w-0 bg-gradient-to-r from-[var(--color-v3-accent)] to-[var(--color-v3-accent-4)] peer-focus:w-full transition-all duration-500 ease-out" />
              </div>
              
              <AnimatePresence>
                {feedback.type && (
                  <motion.div 
                    initial={{ opacity: 0, height: 0, scale: 0.9 }}
                    animate={{ opacity: 1, height: 'auto', scale: 1 }}
                    exit={{ opacity: 0, height: 0, scale: 0.9 }}
                    className={`py-3 px-4 rounded-xl text-sm flex items-center gap-3 ${feedback.type === 'success' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-red-500/10 text-red-500 border border-red-500/20'}`}
                  >
                    {feedback.type === 'success' && <CheckCircle2 className="w-5 h-5 flex-shrink-0" />}
                    {feedback.message}
                  </motion.div>
                )}
              </AnimatePresence>

              <button 
                type="submit"
                disabled={isSubmitting}
                className="nav-pill primary block w-full text-center py-4 mt-4 disabled:opacity-70 disabled:cursor-not-allowed group/btn overflow-hidden relative"
              >
                <span className="relative z-10 flex items-center justify-center gap-2 text-lg">
                  {isSubmitting && <Loader2 className="w-5 h-5 animate-spin" />}
                  {isSubmitting ? 'Sending...' : 'Send Message'}
                </span>
                <div className="absolute inset-0 bg-gradient-to-r from-[var(--color-v3-accent-4)] to-[var(--color-v3-accent)] opacity-0 group-hover/btn:opacity-100 transition-opacity duration-300" />
              </button>
            </form>
          </div>
        </motion.div>
      </div>
    </div>
    </>
  );
}
