import { Link } from 'react-router-dom';
import { Twitter, Linkedin, Instagram, Github, Heart } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="border-t border-[var(--color-v3-outline)] mt-24 py-12 relative overflow-hidden">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-[1px] bg-gradient-to-r from-transparent via-[var(--color-v3-accent)] to-transparent opacity-50" />
      <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-4 gap-12 relative z-10">
        <div className="col-span-1 md:col-span-2">
          <Link to="/" className="text-2xl font-bold tracking-tight text-[var(--color-v3-text)] flex items-center gap-3 group mb-6">
            <div className="w-10 h-10 rounded-xl bg-[var(--color-v3-surface-container-highest)] border border-[var(--color-v3-outline)] text-[var(--color-v3-text)] flex items-center justify-center font-bold text-sm shadow-[0_0_15px_rgba(255,255,255,0.05)] group-hover:shadow-[0_0_20px_rgba(99,102,241,0.3)] group-hover:border-[var(--color-v3-accent)] transition-all duration-300 relative overflow-hidden">
               <div className="absolute inset-0 bg-gradient-to-br from-[var(--color-v3-accent)]/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
               <span className="relative z-10 group-hover:text-[var(--color-v3-accent)] transition-colors">HS</span>
            </div>
            <span className="hidden sm:inline font-display group-hover:text-gradient transition-all duration-300">HS Studio</span>
          </Link>
          <p className="text-[var(--color-v3-text-var)] max-w-sm font-light leading-relaxed">
            I am a full-stack developer and designer focused on building beautiful, performant, and scaleable web experiences for forward-thinking brands.
          </p>
        </div>
        
        <div>
          <h4 className="text-[var(--color-v3-text)] font-semibold mb-6 small-caps tracking-widest text-[var(--color-v3-accent)]">Navigation</h4>
          <ul className="space-y-4">
             <li><Link to="/" className="text-[var(--color-v3-text-var)] hover:text-white hover:translate-x-1 inline-block transition-all duration-300">Home</Link></li>
             <li><Link to="/about" className="text-[var(--color-v3-text-var)] hover:text-white hover:translate-x-1 inline-block transition-all duration-300">About Me</Link></li>
             <li><Link to="/services" className="text-[var(--color-v3-text-var)] hover:text-white hover:translate-x-1 inline-block transition-all duration-300">Services</Link></li>
             <li><Link to="/portfolio" className="text-[var(--color-v3-text-var)] hover:text-white hover:translate-x-1 inline-block transition-all duration-300">Portfolio</Link></li>
             <li><Link to="/payment" className="text-[var(--color-v3-text-var)] hover:text-white hover:translate-x-1 inline-block transition-all duration-300">Pay</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="text-[var(--color-v3-text)] font-semibold mb-6 small-caps tracking-widest text-[var(--color-v3-accent)]">Connect</h4>
          <div className="flex gap-4">
             <a href="#" className="w-10 h-10 rounded-full border border-[var(--color-v3-outline)] flex items-center justify-center text-[var(--color-v3-text-var)] hover:text-white hover:border-[var(--color-v3-accent)] hover:bg-[var(--color-v3-accent)]/10 hover:shadow-[0_0_15px_rgba(99,102,241,0.3)] transition-all duration-300 group">
                <Twitter className="w-4 h-4 group-hover:scale-110 transition-transform" />
             </a>
             <a href="#" className="w-10 h-10 rounded-full border border-[var(--color-v3-outline)] flex items-center justify-center text-[var(--color-v3-text-var)] hover:text-white hover:border-[var(--color-v3-accent)] hover:bg-[var(--color-v3-accent)]/10 hover:shadow-[0_0_15px_rgba(99,102,241,0.3)] transition-all duration-300 group">
                <Linkedin className="w-4 h-4 group-hover:scale-110 transition-transform" />
             </a>
             <a href="#" className="w-10 h-10 rounded-full border border-[var(--color-v3-outline)] flex items-center justify-center text-[var(--color-v3-text-var)] hover:text-white hover:border-[var(--color-v3-accent)] hover:bg-[var(--color-v3-accent)]/10 hover:shadow-[0_0_15px_rgba(99,102,241,0.3)] transition-all duration-300 group">
                <Instagram className="w-4 h-4 group-hover:scale-110 transition-transform" />
             </a>
             <a href="#" className="w-10 h-10 rounded-full border border-[var(--color-v3-outline)] flex items-center justify-center text-[var(--color-v3-text-var)] hover:text-white hover:border-[var(--color-v3-accent)] hover:bg-[var(--color-v3-accent)]/10 hover:shadow-[0_0_15px_rgba(99,102,241,0.3)] transition-all duration-300 group">
                <Github className="w-4 h-4 group-hover:scale-110 transition-transform" />
             </a>
          </div>
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto px-6 mt-16 pt-8 border-t border-[var(--color-v3-outline)] flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-[var(--color-v3-text-var)]">
        <p className="flex items-center gap-1 font-light">
          Made with <Heart className="w-4 h-4 text-rose-500 animate-pulse inline" fill="currentColor" /> by Harsh
        </p>
        <p className="font-light tracking-wide">&copy; {new Date().getFullYear()} HS Studio. All rights reserved.</p>
        <div className="flex space-x-6">
          <Link to="#" className="font-light hover:text-white transition-colors">Privacy Policy</Link>
          <Link to="#" className="font-light hover:text-white transition-colors">Terms of Service</Link>
        </div>
      </div>
    </footer>
  );
}
