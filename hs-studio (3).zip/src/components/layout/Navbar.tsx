import { Link, useLocation } from 'react-router-dom';
import { Menu, X, LogOut, User as UserIcon } from 'lucide-react';
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useAuth } from '../../context/AuthContext';

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();
  const { user, logout } = useAuth();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const links = [
    { name: 'Home', path: '/' },
    { name: 'About', path: '/about' },
    { name: 'Services', path: '/services' },
    { name: 'Portfolio', path: '/portfolio' },
    { name: 'Pay', path: '/payment' },
  ];

  const handleDownloadCV = () => {
    const content = "CV\n\nExperience: 2 Years\nProjects: 20+\nLocation: Balrampur, India";
    const blob = new Blob([content], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "Resume_HS_Studio.txt";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${scrolled ? 'header-gradient py-4 shadow-[0_4px_30px_rgba(0,0,0,0.3)]' : 'bg-transparent py-6'}`}>
      <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
        {/* Logo */}
        <Link to="/" className="text-2xl font-bold tracking-tight text-[var(--color-v3-text)] flex items-center gap-3 group">
          <div className="w-10 h-10 rounded-xl bg-[var(--color-v3-surface-container-highest)] border border-[var(--color-v3-outline)] text-[var(--color-v3-text)] flex items-center justify-center font-bold text-sm shadow-[0_0_15px_rgba(255,255,255,0.05)] group-hover:shadow-[0_0_20px_rgba(99,102,241,0.3)] group-hover:border-[var(--color-v3-accent)] transition-all duration-300 relative overflow-hidden">
             <div className="absolute inset-0 bg-gradient-to-br from-[var(--color-v3-accent)]/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
             <span className="relative z-10 group-hover:text-[var(--color-v3-accent)] transition-colors">HS</span>
          </div>
          <span className="hidden sm:inline font-display group-hover:text-gradient transition-all duration-300">HS Studio</span>
        </Link>

        {/* Desktop Links */}
        <div className="hidden lg:flex items-center space-x-2 bg-[var(--color-v3-surface)]/50 backdrop-blur-md px-2 py-1.5 rounded-full border border-[var(--color-v3-outline-var)]">
          {links.map((link) => {
            const isActive = location.pathname === link.path;
            return (
               <Link
                key={link.name}
                to={link.path}
                className={`relative px-5 py-2 rounded-full text-sm font-medium transition-colors ${isActive ? 'text-white' : 'text-[var(--color-v3-text-var)] hover:text-white'}`}
              >
                {isActive && (
                  <motion.div
                    layoutId="activeTab"
                    className="absolute inset-0 bg-[var(--color-v3-accent)] rounded-full -z-10 shadow-[0_0_15px_rgba(99,102,241,0.4)]"
                    transition={{ type: "spring", stiffness: 380, damping: 30 }}
                  />
                )}
                <span className="relative z-10">{link.name}</span>
              </Link>
            )
          })}
        </div>

        {/* Actions Desktop */}
        <div className="hidden lg:flex items-center gap-4">
          {user ? (
             <div className="flex items-center gap-3 bg-[var(--color-v3-surface-container)] rounded-full pl-3 pr-2 py-1.5 border border-[var(--color-v3-outline)]">
                <span className="text-sm font-medium text-[var(--color-v3-text)] flex items-center gap-2">
                  <UserIcon className="w-4 h-4 text-[var(--color-v3-accent)]" /> {user.name}
                </span>
                <button 
                  onClick={logout}
                  className="bg-[var(--color-v3-surface-container-highest)] hover:bg-[var(--color-v3-surface-container-highest)]/80 text-[var(--color-v3-text-var)] hover:text-white border border-[var(--color-v3-outline-var)] hover:border-[var(--color-v3-accent)]/50 p-1.5 rounded-full transition-all group"
                  title="Logout"
                >
                  <LogOut className="w-4 h-4 group-hover:text-red-400 transition-colors" />
                </button>
             </div>
          ) : (
            <Link to="/login" className="text-sm font-medium text-[var(--color-v3-text)] hover:text-[var(--color-v3-accent)] hover:bg-[var(--color-v3-button-container)] px-5 py-2 rounded-full transition-all duration-300">
              Login
            </Link>
          )}

          <Link to="/contact" className="nav-pill primary text-sm py-2.5 px-6">
            Get in touch
          </Link>
        </div>

        {/* Mobile Menu Toggle */}
        <div className="lg:hidden flex items-center gap-4">
          <button className="text-[var(--color-v3-text)] p-2 bg-[var(--color-v3-surface-container-highest)] rounded-full border border-[var(--color-v3-outline)]" onClick={() => setIsOpen(true)}>
            <Menu className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20, filter: "blur(10px)" }}
            animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
            exit={{ opacity: 0, y: -20, filter: "blur(10px)" }}
            className="fixed inset-0 z-50 bg-[var(--color-v3-surface)]/95 backdrop-blur-xl flex flex-col p-6 border-b border-[var(--color-v3-outline)]"
          >
            <div className="flex justify-between items-center mb-12">
              <Link to="/" className="text-2xl font-bold font-display text-gradient" onClick={() => setIsOpen(false)}>
                HS Studio
              </Link>
              <button onClick={() => setIsOpen(false)} className="text-[var(--color-v3-text)] p-2 bg-[var(--color-v3-surface-container-highest)] rounded-full border border-[var(--color-v3-outline)]">
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="flex flex-col space-y-6 text-2xl font-light">
              {user && (
                 <div className="flex items-center gap-3 text-lg font-medium text-[var(--color-v3-text)] mb-2 p-4 rounded-2xl bg-[var(--color-v3-surface-container)] border border-[var(--color-v3-outline)]">
                    <div className="w-10 h-10 rounded-full bg-[var(--color-v3-accent)]/20 flex items-center justify-center text-[var(--color-v3-accent)]">
                      <UserIcon className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-sm text-[var(--color-v3-text-var)] uppercase tracking-wider font-semibold text-xs">Logged in as</div>
                      <div>{user.name}</div>
                    </div>
                 </div>
              )}
              {links.map((link) => (
                <Link
                  key={link.name}
                  to={link.path}
                  className="text-[var(--color-v3-text-var)] hover:text-[var(--color-v3-accent)] transition-colors"
                  onClick={() => setIsOpen(false)}
                >
                  {link.name}
                </Link>
              ))}
              <hr className="my-6 border-[var(--color-v3-outline)]" />
              
              {!user ? (
                <Link
                  to="/login"
                  className="text-[var(--color-v3-text)] hover:text-[var(--color-v3-accent)] transition-colors text-left"
                  onClick={() => setIsOpen(false)}
                >
                  Login / Register
                </Link>
              ) : (
                <button 
                  onClick={() => { logout(); setIsOpen(false); }}
                  className="text-left text-red-400 hover:text-red-300 transition-colors flex items-center gap-2"
                >
                  <LogOut className="w-6 h-6" /> Logout
                </button>
              )}
              
              <Link
                to="/contact"
                className="text-[var(--color-v3-accent)] font-medium mt-4"
                onClick={() => setIsOpen(false)}
              >
                Contact Us
              </Link>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
