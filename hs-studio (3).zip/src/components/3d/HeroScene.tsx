import { useRef, useMemo, useEffect } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Points, PointMaterial } from '@react-three/drei';
import * as THREE from 'three';

function Particles() {
  const ref = useRef<THREE.Points>(null);
  const scrollRef = useRef(0);

  useEffect(() => {
    const handleScroll = () => {
      scrollRef.current = window.scrollY;
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const [positions, initialPositions] = useMemo(() => {
    const count = 800;
    const positions = new Float32Array(count * 3);
    const initialPositions = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      const radius = 5 + Math.random() * 5;
      const theta = Math.random() * 2 * Math.PI;
      const phi = Math.acos(Math.random() * 2 - 1);
      
      const x = radius * Math.sin(phi) * Math.cos(theta);
      const y = radius * Math.sin(phi) * Math.sin(theta);
      const z = radius * Math.cos(phi);

      positions[i * 3] = x;
      positions[i * 3 + 1] = y;
      positions[i * 3 + 2] = z;
      
      initialPositions[i * 3] = x;
      initialPositions[i * 3 + 1] = y;
      initialPositions[i * 3 + 2] = z;
    }
    return [positions, initialPositions];
  }, []);

  useFrame((state, delta) => {
    if (ref.current) {
      ref.current.rotation.y += delta * 0.1;
      
      const scrollInfluence = Math.min(scrollRef.current / 500, 1);
      
      const positionsArray = ref.current.geometry.attributes.position.array as Float32Array;
      
      for(let i=0; i < 800; i++) {
         const ix = i * 3;
         const iy = i * 3 + 1;
         const iz = i * 3 + 2;
         
         const x = initialPositions[ix];
         const y = initialPositions[iy];
         const z = initialPositions[iz];
         
         // Disperse outwards
         const distance = Math.sqrt(x*x + y*y + z*z);
         const targetX = x * (1 + scrollInfluence * 2);
         const targetY = y * (1 + scrollInfluence * 2);
         const targetZ = z * (1 + scrollInfluence * 2);

         positionsArray[ix] += (targetX - positionsArray[ix]) * 0.1;
         positionsArray[iy] += (targetY - positionsArray[iy]) * 0.1;
         positionsArray[iz] += (targetZ - positionsArray[iz]) * 0.1;
      }
      ref.current.geometry.attributes.position.needsUpdate = true;
    }
  });

  return (
    <Points ref={ref} positions={positions} stride={3} frustumCulled={false}>
      <PointMaterial transparent color="#1A73E8" size={0.06} sizeAttenuation={true} depthWrite={false} opacity={0.7}/>
    </Points>
  );
}

export default function HeroScene() {
  return (
    <div className="absolute inset-0 pointer-events-none z-0">
      <Canvas camera={{ position: [0, 0, 10], fov: 75 }} gl={{ antialias: false, alpha: true }}>
        <Particles />
      </Canvas>
    </div>
  );
}
