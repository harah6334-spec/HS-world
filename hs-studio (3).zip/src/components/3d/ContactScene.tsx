import { useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import * as THREE from 'three';

function ContactOrbs() {
  const orb1 = useRef<THREE.Mesh>(null);
  const orb2 = useRef<THREE.Mesh>(null);
  const orb3 = useRef<THREE.Mesh>(null);
  
  useFrame((state) => {
    if (orb1.current) {
      const scale = 1 + Math.sin(state.clock.elapsedTime * 2.5) * 0.15;
      orb1.current.scale.set(scale, scale, scale);
      orb1.current.position.y = Math.sin(state.clock.elapsedTime * 2) * 0.4;
    }
    if (orb2.current) {
      const scale = 1 + Math.cos(state.clock.elapsedTime * 2) * 0.1;
      orb2.current.scale.set(scale, scale, scale);
      orb2.current.position.y = Math.cos(state.clock.elapsedTime * 1.5) * 0.6;
    }
    if (orb3.current) {
      const scale = 1 + Math.sin(state.clock.elapsedTime * 1.5 + Math.PI) * 0.2;
      orb3.current.scale.set(scale, scale, scale);
      orb3.current.position.x = 2 + Math.cos(state.clock.elapsedTime * 1.2) * 0.5;
    }
  });

  return (
    <group>
      <mesh ref={orb1} position={[-2, 1.5, 0]}>
        <sphereGeometry args={[1.8, 64, 64]} />
        <meshBasicMaterial color="#6366f1" transparent opacity={0.6} />
      </mesh>
      <mesh ref={orb2} position={[2.5, -1.5, -2]}>
        <sphereGeometry args={[2.2, 64, 64]} />
        <meshBasicMaterial color="#4f46e5" transparent opacity={0.5} />
      </mesh>
      <mesh ref={orb3} position={[2, 2, -4]}>
        <sphereGeometry args={[1.5, 64, 64]} />
        <meshBasicMaterial color="#a855f7" transparent opacity={0.4} />
      </mesh>
    </group>
  );
}

export default function ContactScene() {
  return (
    <div className="absolute inset-0 pointer-events-none z-0 overflow-hidden">
      <Canvas camera={{ position: [0, 0, 8], fov: 75 }} gl={{ antialias: false, alpha: true }}>
        <ContactOrbs />
      </Canvas>
    </div>
  );
}
