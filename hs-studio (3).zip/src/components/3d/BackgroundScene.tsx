import { useRef, useMemo } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import { Points, PointMaterial } from '@react-three/drei';
import * as THREE from 'three';

export function ParallaxStars() {
  const ref = useRef<THREE.Points>(null);
  const { mouse, viewport } = useThree();

  const [positions, scales] = useMemo(() => {
    const positions = new Float32Array(3000 * 3);
    const scales = new Float32Array(3000);
    for (let i = 0; i < 3000; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 20; // x
      positions[i * 3 + 1] = (Math.random() - 0.5) * 20; // y
      positions[i * 3 + 2] = (Math.random() - 0.5) * 10 - 5; // z
      scales[i] = Math.random();
    }
    return [positions, scales];
  }, []);

  useFrame((state, delta) => {
    if (ref.current) {
      ref.current.rotation.x -= delta / 50;
      ref.current.rotation.y -= delta / 30;
      
      // Parallax effect based on mouse
      const targetX = (mouse.x * viewport.width) / 10;
      const targetY = (mouse.y * viewport.height) / 10;
      ref.current.position.x += (targetX - ref.current.position.x) * 0.02;
      ref.current.position.y += (targetY - ref.current.position.y) * 0.02;
    }
  });

  return (
    <Points ref={ref} positions={positions} stride={3} frustumCulled={false}>
      <PointMaterial transparent color="#1A73E8" size={0.03} sizeAttenuation={true} depthWrite={false} opacity={0.6}/>
    </Points>
  );
}

export function GlowingSphere({ color = '#1e40af', position = [0, 0, -5] as [number, number, number] }) {
  const ref = useRef<THREE.Mesh>(null);
  const targetColor = useMemo(() => new THREE.Color(), []);
  
  useFrame((state, delta) => {
    if (ref.current) {
      // Pulsing effect
      const scale = 1 + Math.sin(state.clock.elapsedTime * 2) * 0.05;
      ref.current.scale.set(scale, scale, scale);
      
      targetColor.set(color);
      (ref.current.material as THREE.MeshBasicMaterial).color.lerp(targetColor, delta * 2);
    }
  });

  return (
    <mesh ref={ref} position={position}>
      <sphereGeometry args={[2, 64, 64]} />
      <meshBasicMaterial color={color} transparent opacity={0.25} />
    </mesh>
  );
}

export function FloatingGeometry({ position = [0, 0, 0] as [number, number, number] }) {
  const group = useRef<THREE.Group>(null);
  const mesh1 = useRef<THREE.Mesh>(null);
  const mesh2 = useRef<THREE.Mesh>(null);

  useFrame((state, delta) => {
    if (mesh1.current) {
      mesh1.current.rotation.x += delta * 0.2;
      mesh1.current.rotation.y += delta * 0.3;
    }
    if (mesh2.current) {
      mesh2.current.rotation.x -= delta * 0.1;
      mesh2.current.rotation.y -= delta * 0.4;
    }
    if (group.current) {
       group.current.position.y = position[1] + Math.sin(state.clock.elapsedTime) * 0.2;
    }
  });

  return (
    <group ref={group} position={position}>
      <mesh ref={mesh1}>
        <icosahedronGeometry args={[1, 0]} />
        <meshBasicMaterial color="#34A853" wireframe transparent opacity={0.3} />
      </mesh>
      <mesh ref={mesh2} scale={1.5}>
        <octahedronGeometry args={[1, 0]} />
        <meshBasicMaterial color="#1A73E8" wireframe transparent opacity={0.4} />
      </mesh>
    </group>
  );
}
