import { EffectComposer, Bloom, ChromaticAberration } from '@react-three/postprocessing';
import { BlendFunction } from 'postprocessing';
import * as THREE from 'three';
import { forwardRef } from 'react';

const PostEffects = forwardRef((props, ref) => {
  return (
    <EffectComposer multisampling={0}>
      <Bloom 
        luminanceThreshold={0.1} 
        luminanceSmoothing={0.9} 
        intensity={3.0} 
        opacity={1}
      />
      <ChromaticAberration 
        blendFunction={BlendFunction.NORMAL} 
        offset={new THREE.Vector2(0.002, 0.002)} 
        radialModulation={false}
        modulationOffset={0}
      />
    </EffectComposer>
  );
});

export default PostEffects;
