import { useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import * as THREE from 'three';

function Geometry() {
  const group = useRef<THREE.Group>(null);
  const mesh1 = useRef<THREE.Mesh>(null);
  const mesh2 = useRef<THREE.Mesh>(null);

  useFrame((state, delta) => {
    if (mesh1.current) {
      mesh1.current.rotation.x += delta * 0.3;
      mesh1.current.rotation.y += delta * 0.4;
    }
    if (mesh2.current) {
      mesh2.current.rotation.x -= delta * 0.15;
      mesh2.current.rotation.y -= delta * 0.25;
    }
    if (group.current) {
       group.current.position.y = Math.sin(state.clock.elapsedTime) * 0.3;
    }
  });

  return (
    <group ref={group}>
      <mesh ref={mesh1}>
        <icosahedronGeometry args={[2.5, 0]} />
        <meshBasicMaterial color="#6366f1" wireframe transparent opacity={0.4} />
      </mesh>
      <mesh ref={mesh2} scale={1.3}>
        <octahedronGeometry args={[2.5, 0]} />
        <meshBasicMaterial color="#a855f7" wireframe transparent opacity={0.3} />
      </mesh>
    </group>
  );
}

export default function AboutScene() {
  return (
    <div className="absolute inset-0 pointer-events-none z-0 overflow-hidden">
      <Canvas camera={{ position: [0, 0, 10], fov: 75 }} gl={{ antialias: false, alpha: true }}>
        <Geometry />
      </Canvas>
    </div>
  );
}
