import { useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import * as THREE from 'three';

function Torus() {
  const ref = useRef<THREE.Mesh>(null);
  
  useFrame((state, delta) => {
    if (ref.current) {
      ref.current.rotation.x += delta * 0.2;
      ref.current.rotation.y += delta * 0.3;
      ref.current.position.y = Math.sin(state.clock.elapsedTime) * 0.2;
    }
  });

  return (
    <mesh ref={ref}>
      <torusKnotGeometry args={[10, 3, 100, 16]} />
      <meshBasicMaterial color="#10b981" wireframe transparent opacity={0.6} />
    </mesh>
  );
}

export default function WireframeTorusScene() {
  return (
    <div className="absolute inset-0 pointer-events-none z-0 overflow-hidden">
      <Canvas camera={{ position: [0, 0, 30], fov: 75 }} gl={{ antialias: false, alpha: true }}>
        <Torus />
      </Canvas>
    </div>
  );
}
